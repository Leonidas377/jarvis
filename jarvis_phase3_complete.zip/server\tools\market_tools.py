# ==========================================================================
# JARVIS Financial Market Demo Data Tool
# ==========================================================================

from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field
from server.tools.base import BaseTool
from server.models.schemas import RiskLevel
from server.permissions.scopes import Scope

class MarketDataInput(BaseModel):
    symbols: Optional[List[str]] = Field(default=["S&P 500", "NASDAQ", "NVDA", "AAPL", "BTC/USD"], description="List of financial ticker symbols")

class GetMarketDemoDataTool(BaseTool):
    name = "get_market_demo_data"
    version = "1.0.0"
    description = "Retrieves current market indicators, prices, and volatility (SIMULATED DATA ONLY)."
    risk_level = RiskLevel.R0_SAFE.value
    required_scope = Scope.MARKET_READ.value
    requires_confirmation = False
    input_schema = MarketDataInput

    async def execute(self, params: MarketDataInput, context: Dict[str, Any]) -> Dict[str, Any]:
        simulated_quotes = {
            "S&P 500": {"price": "5,842.10", "change": "+0.59%", "volume": "3.4B", "status": "NYSE Open"},
            "NASDAQ": {"price": "18,410.50", "change": "+0.78%", "volume": "4.8B", "status": "NASDAQ Open"},
            "NVDA": {"price": "138.45", "change": "+2.33%", "volume": "62.1M", "status": "Active"},
            "AAPL": {"price": "232.10", "change": "-0.36%", "volume": "41.2M", "status": "Active"},
            "BTC/USD": {"price": "68,420.00", "change": "+2.73%", "volume": "28.4B", "status": "24/7 Global"}
        }

        requested_data = {}
        for s in params.symbols:
            if s in simulated_quotes:
                requested_data[s] = simulated_quotes[s]
            else:
                requested_data[s] = {"price": "100.00", "change": "0.00%", "status": "Simulated"}

        return {
            "notice": "DEMO DATA // SIMULATED FEED // NO FINANCIAL TRADING ALLOWED",
            "timestamp": "2026-09-10 09:30:00 EST",
            "quotes": requested_data
        }
