# ==========================================================================
# JARVIS Database Management: SQLite WAL Mode with aiosqlite
# ==========================================================================

import aiosqlite
from pathlib import Path
from server.config import settings

class DBContextManager:
    async def __aenter__(self):
        self.db = await aiosqlite.connect(str(settings.DATABASE_FILE))
        self.db.row_factory = aiosqlite.Row
        await self.db.execute("PRAGMA journal_mode = WAL;")
        await self.db.execute("PRAGMA foreign_keys = ON;")
        return self.db

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.db.close()

class _DBConnectionAwaitable:
    def __await__(self):
        async def _f():
            return DBContextManager()
        return _f().__await__()

    async def __aenter__(self):
        self._cm = DBContextManager()
        return await self._cm.__aenter__()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self._cm.__aexit__(exc_type, exc_val, exc_tb)

def get_db_connection():
    """Provides an active async SQLite connection configured with WAL and foreign keys."""
    return _DBConnectionAwaitable()

async def init_db():
    """Initializes all required normalized database tables."""
    async with await get_db_connection() as db:
        # 1. Users Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id TEXT PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                hashed_password TEXT NOT NULL,
                display_name TEXT NOT NULL,
                created_at TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'active'
            );
        """)

        # 2. Conversations Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                title TEXT NOT NULL,
                mode TEXT NOT NULL DEFAULT 'assistant',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 3. Messages Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                conversation_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                citations_json TEXT,
                uncertainty TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (conversation_id) REFERENCES conversations (id) ON DELETE CASCADE,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 4. Tasks Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                priority TEXT NOT NULL DEFAULT 'medium',
                category TEXT NOT NULL DEFAULT 'general',
                status TEXT NOT NULL DEFAULT 'active',
                progress INTEGER NOT NULL DEFAULT 0,
                due_date TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 5. Memories Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                category TEXT NOT NULL,
                key TEXT NOT NULL,
                value TEXT NOT NULL,
                user_approved INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 6. Tool Executions Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS tool_executions (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                conversation_id TEXT,
                tool_name TEXT NOT NULL,
                tool_version TEXT NOT NULL DEFAULT '1.0.0',
                parameters_json TEXT NOT NULL,
                result_json TEXT,
                risk_level TEXT NOT NULL DEFAULT 'R0_SAFE',
                execution_status TEXT NOT NULL DEFAULT 'success',
                duration_ms INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 7. Approval Requests Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS approval_requests (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                conversation_id TEXT,
                tool_name TEXT NOT NULL,
                summary TEXT NOT NULL,
                parameters_json TEXT NOT NULL,
                risk_level TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                rejection_reason TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 8. Audit Events Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS audit_events (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                event_type TEXT NOT NULL,
                actor TEXT NOT NULL,
                resource_type TEXT NOT NULL,
                resource_id TEXT,
                summary TEXT NOT NULL,
                status TEXT NOT NULL,
                correlation_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 9. Search Queries Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS search_queries (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                query TEXT NOT NULL,
                filters_json TEXT,
                provider TEXT NOT NULL,
                result_count INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'completed',
                correlation_id TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 10. Search Results Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS search_results (
                id TEXT PRIMARY KEY,
                query_id TEXT NOT NULL,
                provider_result_id TEXT,
                title TEXT NOT NULL,
                url TEXT NOT NULL,
                canonical_url TEXT,
                domain TEXT NOT NULL,
                publisher TEXT,
                snippet TEXT,
                published_date TEXT,
                rank INTEGER NOT NULL DEFAULT 0,
                retrieval_timestamp TEXT NOT NULL,
                saved INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY (query_id) REFERENCES search_queries (id) ON DELETE CASCADE
            );
        """)

        # 11. Source Documents Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS source_documents (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                url TEXT NOT NULL,
                canonical_url TEXT,
                title TEXT,
                publisher TEXT,
                author TEXT,
                published_date TEXT,
                access_timestamp TEXT NOT NULL,
                extraction_status TEXT NOT NULL,
                content_hash TEXT,
                extracted_text TEXT,
                headings_json TEXT,
                content_expiry TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 12. Research Reports Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS research_reports (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                title TEXT NOT NULL,
                request_query TEXT NOT NULL,
                executive_summary TEXT NOT NULL,
                key_facts_json TEXT NOT NULL,
                source_comparison_json TEXT,
                analysis TEXT,
                unknowns_and_limitations TEXT,
                citations_json TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'completed',
                saved INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 13. News Topics Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS news_topics (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                topic_name TEXT NOT NULL,
                query TEXT NOT NULL,
                category TEXT,
                region TEXT,
                notifications_enabled INTEGER NOT NULL DEFAULT 0,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
            );
        """)

        # 14. News Event Clusters Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS news_event_clusters (
                id TEXT PRIMARY KEY,
                representative_headline TEXT NOT NULL,
                summary TEXT NOT NULL,
                first_observed_at TEXT NOT NULL,
                last_observed_at TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'General',
                importance_level TEXT NOT NULL DEFAULT 'normal'
            );
        """)

        # 15. News Items Table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS news_items (
                id TEXT PRIMARY KEY,
                provider_item_id TEXT,
                headline TEXT NOT NULL,
                summary TEXT,
                url TEXT NOT NULL,
                canonical_url TEXT,
                publisher TEXT NOT NULL,
                author TEXT,
                published_at TEXT NOT NULL,
                retrieval_timestamp TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'General',
                region TEXT DEFAULT 'Global',
                related_entities_json TEXT,
                cluster_id TEXT,
                is_read INTEGER NOT NULL DEFAULT 0,
                is_saved INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY (cluster_id) REFERENCES news_event_clusters (id) ON DELETE SET NULL
            );
        """)

        # Indexes for fast lookup
        await db.execute("CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations (user_id);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages (conversation_id);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks (user_id);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_approvals_user_status ON approval_requests (user_id, status);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_search_queries_user ON search_queries (user_id);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_search_results_query ON search_results (query_id);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_source_docs_url ON source_documents (url);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_reports_user ON research_reports (user_id);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_news_items_cat ON news_items (category);")
        await db.execute("CREATE INDEX IF NOT EXISTS idx_news_topics_user ON news_topics (user_id);")

        # Seed default user for demo / offline operation
        await db.execute("""
            INSERT OR IGNORE INTO users (id, username, email, hashed_password, display_name, status, created_at)
            VALUES ('default-tony-stark', 'tony_stark', 'tony@starkindustries.com', 'seeded_default_hash', 'Tony Stark', 'active', datetime('now'))
        """)

        await db.commit()
