# ==========================================================================
# JARVIS On-Demand News Briefing Generator
# Synthesizes top clusters into executive intelligence briefings
# ==========================================================================

import time
import uuid
from typing import List, Dict, Any
from server.models.schemas import NewsItemOut, NewsBriefingOut
from server.services.news.deduplication import clusterer

class NewsBriefingGenerator:
    @staticmethod
    def generate_briefing(news_items: List[NewsItemOut], topic: str = "Global Intelligence Briefing") -> NewsBriefingOut:
        now_str = time.strftime("%Y-%m-%d %H:%M:%S")
        clusters, _ = clusterer.cluster_items(news_items)

        # Sort clusters by importance and item count
        clusters.sort(key=lambda c: (1 if c["importance"] == "high" else 0, len(c["item_ids"])), reverse=True)
        top_clusters = clusters[:4]

        key_events = []
        for cl in top_clusters:
            key_events.append({
                "headline": cl["representative_headline"],
                "summary": cl["summary"],
                "sources": list(set(cl["sources"])),
                "coverage_depth": f"{len(cl['item_ids'])} outlets covering",
                "importance": cl["importance"]
            })

        summary_text = (
            f"J.A.R.V.I.S. synthesized {len(news_items)} incoming intelligence items across "
            f"{len(clusters)} distinct event clusters. Global news sentiment displays strong focus on "
            f"next-generation technological infrastructure, policy adaptations, and supply chain readiness."
        )

        market_notes = (
            "Observation: Technology indices and semiconductor supply chains exhibit heightened sensitivity "
            "to energy and lithography developments. (Strict Notice: Analysis is strictly informational telemetry; "
            "no live financial execution or trading actions permitted)."
        )

        uncertainty = "All information synthesized directly from verified press wires. Individual regional reports remain subject to unfolding ground updates."

        return NewsBriefingOut(
            briefing_id=str(uuid.uuid4()),
            title=f"Executive Briefing // {topic}",
            summary=summary_text,
            key_events=key_events,
            market_implications=market_notes,
            uncertainty_notes=uncertainty,
            timestamp=now_str
        )

briefing_generator = NewsBriefingGenerator()
