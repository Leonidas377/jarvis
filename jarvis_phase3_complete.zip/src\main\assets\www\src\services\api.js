// ==========================================================================
// JARVIS API Client: Connects Frontend HUD to Python FastAPI Backend
// With offline fallback, token management, and approval handling
// ==========================================================================

const BASE_URL = window.location.origin.includes('localhost') || window.location.origin.includes('127.0.0.1')
  ? window.location.origin
  : 'http://127.0.0.1:8000';

class JarvisApiClient {
  constructor() {
    this.token = localStorage.getItem('JARVIS_JWT_TOKEN') || null;
    this.activeConversationId = localStorage.getItem('JARVIS_ACTIVE_CONV_ID') || null;
  }

  setToken(token) {
    this.token = token;
    if (token) {
      localStorage.setItem('JARVIS_JWT_TOKEN', token);
    } else {
      localStorage.removeItem('JARVIS_JWT_TOKEN');
    }
  }

  setActiveConversation(convId) {
    this.activeConversationId = convId;
    if (convId) {
      localStorage.setItem('JARVIS_ACTIVE_CONV_ID', convId);
    } else {
      localStorage.removeItem('JARVIS_ACTIVE_CONV_ID');
    }
  }

  async request(endpoint, options = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const config = {
      ...options,
      headers
    };

    try {
      const response = await fetch(`${BASE_URL}${endpoint}`, config);
      if (!response.ok) {
        let errDetail = `HTTP ${response.status}: ${response.statusText}`;
        try {
          const errJson = await response.json();
          if (errJson.detail) errDetail = errJson.detail;
        } catch (_) {}
        throw new Error(errDetail);
      }
      return await response.json();
    } catch (error) {
      console.warn(`[JARVIS API] Request to ${endpoint} failed:`, error.message);
      throw error;
    }
  }

  // Auth
  async login(username, password) {
    const data = await this.request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });
    if (data && data.access_token) {
      this.setToken(data.access_token);
    }
    return data;
  }

  async getMe() {
    return await this.request('/api/auth/me');
  }

  // System Telemetry & Status
  async getSystemStatus() {
    return await this.request('/api/system/status');
  }

  async getTools() {
    return await this.request('/api/tools');
  }

  // AI Chat & Orchestration
  async sendChat(content, conversationId = null, approvalId = null) {
    const convId = conversationId || this.activeConversationId;
    const data = await this.request('/api/chat', {
      method: 'POST',
      body: JSON.stringify({
        content,
        conversation_id: convId,
        approval_id: approvalId
      })
    });

    if (data.conversation_id) {
      this.setActiveConversation(data.conversation_id);
    }
    return data;
  }

  // Directives / Tasks
  async getTasks(status = null) {
    const query = status ? `?status=${encodeURIComponent(status)}` : '';
    return await this.request(`/api/tasks${query}`);
  }

  async createTask(title, description = '', priority = 'medium', category = 'general', dueDate = 'Tomorrow') {
    return await this.request('/api/tasks', {
      method: 'POST',
      body: JSON.stringify({
        title,
        description,
        priority,
        category,
        due_date: dueDate
      })
    });
  }

  async updateTask(taskId, updates) {
    return await this.request(`/api/tasks/${taskId}`, {
      method: 'PUT',
      body: JSON.stringify(updates)
    });
  }

  async deleteTask(taskId) {
    return await this.request(`/api/tasks/${taskId}`, {
      method: 'DELETE'
    });
  }

  // Human-in-the-Loop Approvals
  async getPendingApprovals() {
    return await this.request('/api/approvals');
  }

  async decideApproval(approvalId, action, reason = null) {
    return await this.request(`/api/approvals/${approvalId}/decide`, {
      method: 'POST',
      body: JSON.stringify({ action, reason })
    });
  }

  async executeApproval(approvalId) {
    return await this.request(`/api/approvals/${approvalId}/execute`, {
      method: 'POST'
    });
  }

  // Episodic Memory
  async getMemories(query = null) {
    const q = query ? `?q=${encodeURIComponent(query)}` : '';
    return await this.request(`/api/memories${q}`);
  }

  async createMemory(category, key, value) {
    return await this.request('/api/memories', {
      method: 'POST',
      body: JSON.stringify({ category, key, value })
    });
  }

  async deleteMemory(memoryId) {
    return await this.request(`/api/memories/${memoryId}`, {
      method: 'DELETE'
    });
  }

  // Audit Logs
  async getAuditLogs(limit = 50) {
    return await this.request(`/api/audit?limit=${limit}`);
  }
}

export const jarvisApi = new JarvisApiClient();
