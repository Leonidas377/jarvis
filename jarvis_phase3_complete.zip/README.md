# J.A.R.V.I.S. Personal AI Assistant & Autonomous Intelligence System

A multi-platform personal AI assistant combining a futuristic cyan Stark HUD interface with a secure Python FastAPI backend, episodic memory, human-in-the-loop approval workflows, real-time web research, verified citations, news intelligence, and Android mobile integration.

---

## System Overview

```
                      ┌────────────────────────────────────────────────────────┐
                      │          J.A.R.V.I.S. Futuristic Stark HUD UI         │
                      │       (Android Native WebView / Desktop Browser)       │
                      └───────────────────────────┬────────────────────────────┘
                                                  │ REST / JWT Auth / WebSockets
                                                  ▼
                      ┌────────────────────────────────────────────────────────┐
                      │               FastAPI Backend Gateway                  │
                      ├───────────────────────────┬────────────────────────────┤
                      │  /api/auth   • /api/chat  │  /api/research/search      │
                      │  /api/tasks  • /api/audit │  /api/research/reports     │
                      │  /api/memory • /api/tools │  /api/news & briefings     │
                      └─────────────┬─────────────────────────────┬────────────┘
                                    │                             │
                      ┌─────────────▼─────────────┐ ┌─────────────▼────────────┐
                      │     AI Orchestrator       │ │  Web Research & News Core │
                      │  • State Machine Pipeline │ │  • DuckDuckGo Web Search │
                      │  • Policy Engine (R0-R4)  │ │  • Hardened SSRF Filter  │
                      │  • Human Approval Gates   │ │  • Anti-Prompt Injection │
                      │  • 17 Safe Tools Catalog  │ │  • Structured Citations  │
                      └─────────────┬─────────────┘ └─────────────┬────────────┘
                                    │                             │
                                    ▼                             ▼
                      ┌────────────────────────────────────────────────────────┐
                      │            SQLite WAL Storage & Vector Index           │
                      │  conversations • messages • tasks • memories • reports │
                      └────────────────────────────────────────────────────────┘
```

---

## Phase Implementations

### Phase 1: Functional Android HUD UI
- **Design Aesthetic**: Stark/JARVIS holographic cyan telemetry, scanlines, arc-style assistant emblem, chamfered cards.
- **Components**: Dynamic vocal waveform visualizer, collapsible bottom navigation, quick-action telemetry pills.
- **Android Integration**: Native Android WebView wrapper with Java/Kotlin bridge, hardware back button support, and vibration haptics.

### Phase 2: Backend Foundation & AI Orchestration
- **Security**: PBKDF2-HMAC-SHA256 password hashing, HS256 JWT tokens, constant-time verification.
- **Orchestration**: Discrete state machine (`RECEIVED` ➔ `VALIDATING` ➔ `PLANNING` ➔ `PERMISSION_CHECK` ➔ `APPROVAL` ➔ `EXECUTE` ➔ `RESPOND`).
- **Policy Engine**: Risk tiers R0 (safe auto-execute), R1 (low), R2–R3 (mandatory human authorization gate with TTL), and R4 (strictly blocked live trading).
- **Episodic Memory**: User-approved preference and fact storage with audit trails.

### Phase 3: Real Web Search, Citations & News Intelligence
- **Web Search**: Real search provider integration (DuckDuckGo live HTML provider with canonical URL unwrap, plus labeled demo fallback).
- **SSRF Security Gate**: Blocks loopback (`127.0.0.1`, `localhost`, `::1`), private ranges (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`), cloud metadata (`169.254.169.254`), and unsafe URL schemes (`file:`, `javascript:`, `data:`).
- **Content Extractor**: Strips scripts, styles, and navigation; extracts OpenGraph metadata; isolates untrusted content with anti-prompt-injection fences.
- **Citation Engine**: Structured citations (`[CIT-01]`, `[CIT-02]`, etc.) with evidence excerpts and automated removal of hallucinated citation IDs.
- **News Intelligence**: Live multi-feed RSS aggregator, Jaccard token similarity deduplication, event clustering, topic subscriptions, and on-demand executive briefings with strictly read-only market notes.

---

## Quickstart & Execution

### 1. Requirements
- Python 3.11+ (Python 3.14 compatible)
- Node.js / Modern Web Browser
- Android SDK (for building native APK)

### 2. Install Dependencies
```bash
pip install -r requirements.txt
pip install beautifulsoup4 feedparser
```

### 3. Start the Backend Server
```bash
python -m uvicorn server.main:app --host 127.0.0.1 --port 8000 --reload
```

### 4. Access the Holographic Web HUD
Open your browser at:
```
http://127.0.0.1:8000/
```

- **OpenAPI Swagger Documentation**: `http://127.0.0.1:8000/docs`
- **Default Test Credentials**:
  - Username: `tony_stark`
  - Password: `starkpassword123` (or register a new user in HUD)

### 5. Run the Automated Test Suite (28 Tests)
```bash
python -m pytest tests/ -v
```

### 6. Run the Live Phase 3 Demonstration
```bash
python scripts/showcase_phase3.py
```

---

## Android Mobile Application

- **Gradle Build Command**:
  ```powershell
  .\gradlew.bat assembleDebug
  ```
- **Compiled Output**:
  `app/build/outputs/apk/debug/app-debug.apk`
- The APK embeds all updated HUD web assets directly in `app/src/main/assets/www/` with full offline cache fallback.

---

## Security & Guardrails Notice

- **Zero Live Trading**: Financial market execution, automated broker trades, and external purchasing actions are strictly disabled. All market telemetry is strictly observational read-only analysis.
- **Zero Hallucinated Citations**: If a source fails to fetch or cannot be extracted, JARVIS truthful status determination flags it (`NO_ARTICLE_CONTENT`, `FETCH_FAILED`, `BLOCKED`) rather than inventing content.
