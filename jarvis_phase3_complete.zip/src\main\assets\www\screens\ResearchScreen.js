// ==========================================================================
// Research Screen: Real Web Intelligence, Source Extraction & Cited Reports
// ==========================================================================

import { store } from '../services/store.js';
import { jarvisApi } from '../services/api.js';

let activeTab = 'search'; // 'search' | 'reports' | 'history'
let searchQuery = '';
let searchResults = [];
let searchMetadata = null;
let isSearching = false;
let isGeneratingReport = false;
let activeReport = null; // Currently opened full report modal
let activeSummary = null; // Currently opened single-source summary modal
let savedReports = [];
let searchHistory = [];
let selectedUrlsForReport = new Set();
let providerStatus = 'ONLINE'; // 'ONLINE' | 'OFFLINE' | 'ERROR'

export function setResearchTab(tab) {
  activeTab = tab;
  if (tab === 'reports') {
    loadSavedReports();
  } else if (tab === 'history') {
    loadSearchHistory();
  }
  window.jarvisApp.render();
}

export async function executeSearch(query) {
  if (!query || !query.trim()) return;
  searchQuery = query.trim();
  isSearching = true;
  activeTab = 'search';
  window.jarvisApp.render();

  try {
    const data = await jarvisApi.searchWeb(searchQuery, null, 'us-en', 8);
    searchResults = data.results || [];
    searchMetadata = {
      query: data.query,
      provider: data.provider,
      count: data.count,
      timestamp: new Date().toLocaleTimeString()
    };
    providerStatus = data.provider === 'DuckDuckGo' ? 'LIVE DUCKDUCKGO' : 'DEMO MODE';
    selectedUrlsForReport.clear();
    // Default select top 3 for convenience
    searchResults.slice(0, 3).forEach(r => selectedUrlsForReport.add(r.url));
  } catch (err) {
    console.error('Search request failed:', err);
    providerStatus = err.message.includes('PROVIDER_NOT_CONFIGURED') ? 'PROVIDER NOT CONFIGURED' : 'ERROR';
    searchResults = [];
    searchMetadata = { query: searchQuery, error: err.message };
  } finally {
    isSearching = false;
    window.jarvisApp.render();
  }
}

export async function loadSavedReports() {
  try {
    const data = await jarvisApi.getResearchReports();
    savedReports = data.reports || [];
  } catch (err) {
    console.warn('Failed to load saved reports:', err);
  }
  window.jarvisApp.render();
}

export async function loadSearchHistory() {
  try {
    const data = await jarvisApi.getSearchHistory();
    searchHistory = data.history || [];
  } catch (err) {
    console.warn('Failed to load search history:', err);
  }
  window.jarvisApp.render();
}

export function toggleSourceSelection(url) {
  if (selectedUrlsForReport.has(url)) {
    selectedUrlsForReport.delete(url);
  } else {
    selectedUrlsForReport.add(url);
  }
  window.jarvisApp.render();
}

export async function generateCitedReport() {
  if (selectedUrlsForReport.size === 0 && searchResults.length === 0) {
    alert('Please execute a search and select at least one source.');
    return;
  }
  const urls = Array.from(selectedUrlsForReport);
  isGeneratingReport = true;
  window.jarvisApp.render();

  try {
    const report = await jarvisApi.createResearchReport(
      searchQuery || 'Web Investigation',
      searchQuery,
      urls.length > 0 ? urls : searchResults.slice(0, 3).map(r => r.url),
      ['Key Developments', 'Authoritative Claims', 'Implications']
    );
    activeReport = report;
    loadSavedReports();
  } catch (err) {
    alert(`Report generation failed: ${err.message}`);
  } finally {
    isGeneratingReport = false;
    window.jarvisApp.render();
  }
}

export async function openReportDetail(reportId) {
  try {
    const report = await jarvisApi.getResearchReport(reportId);
    activeReport = report;
    window.jarvisApp.render();
  } catch (err) {
    alert(`Could not load report: ${err.message}`);
  }
}

export function closeReportModal() {
  activeReport = null;
  window.jarvisApp.render();
}

export async function deleteReportAction(reportId) {
  if (confirm('Delete this cited research report from database?')) {
    try {
      await jarvisApi.deleteResearchReport(reportId);
      if (activeReport && activeReport.id === reportId) {
        activeReport = null;
      }
      loadSavedReports();
    } catch (err) {
      alert(`Deletion failed: ${err.message}`);
    }
  }
}

export async function summarizeSingleSource(url, title) {
  window.jarvisApp.playHudBeep(850, 0.04);
  activeSummary = { loading: true, title, url };
  window.jarvisApp.render();

  try {
    const doc = await jarvisApi.fetchSource(url);
    const summary = await jarvisApi.summarizeSource(doc.id);
    activeSummary = {
      loading: false,
      title: doc.title || title,
      publisher: doc.publisher,
      author: doc.author,
      published_at: doc.published_at || 'Date unavailable',
      status: doc.extraction_status,
      summary: summary.summary,
      key_facts: summary.key_facts || [],
      url: doc.url
    };
  } catch (err) {
    activeSummary = {
      loading: false,
      title,
      url,
      error: err.message
    };
  }
  window.jarvisApp.render();
}

export function closeSummaryModal() {
  activeSummary = null;
  window.jarvisApp.render();
}

export function openExternalUrl(url) {
  if (!url) return;
  // Safe external link opener - no scripts execution
  window.open(url, '_blank', 'noopener,noreferrer');
}

export function renderResearchScreen() {
  const state = store.state;

  return `
    <div class="screen-container hud-scroll" style="flex: 1; padding: 14px 14px 84px 14px; display: flex; flex-direction: column; gap: 14px;">
      
      <!-- Top Title Bar with Navigation -->
      <div style="display: flex; align-items: center; justify-content: space-between;">
        <div>
          <span class="label-caps" style="color: var(--cyan-core); letter-spacing: 0.15em;">REAL WEB INTELLIGENCE</span>
          <h2 class="hud-title" style="font-size: 18px; margin-top: 2px;">Research & Citations</h2>
        </div>

        <div style="display: flex; gap: 6px; align-items: center;">
          <span class="badge ${providerStatus.includes('LIVE') ? 'badge-cyan' : providerStatus.includes('NOT CONFIGURED') ? 'badge-red' : 'badge-amber'}" style="font-size: 8px;">
            ${providerStatus}
          </span>
          <button onclick="window.jarvisApp.navigate('news')" class="hud-btn" style="padding: 6px 10px; font-size: 10px;">
            <span class="material-symbols-outlined" style="font-size: 14px;">newspaper</span>
            News Feed
          </button>
        </div>
      </div>

      <!-- Navigation Tabs (Search / Saved Reports / History) -->
      <div style="display: flex; gap: 6px; border-bottom: 1px solid rgba(0, 240, 255, 0.15); padding-bottom: 6px;">
        <button onclick="window.jarvisApp.setResearchTab('search')" style="
          background: ${activeTab === 'search' ? 'var(--cyan-core)' : 'transparent'};
          color: ${activeTab === 'search' ? 'var(--bg-void)' : 'var(--text-secondary)'};
          border: 1px solid ${activeTab === 'search' ? 'var(--cyan-core)' : 'rgba(0, 240, 255, 0.2)'};
          font-family: var(--font-telemetry);
          font-size: 10px;
          font-weight: 700;
          padding: 6px 12px;
          cursor: pointer;
          clip-path: var(--chamfer-clip-sm);
        ">
          LIVE SEARCH
        </button>

        <button onclick="window.jarvisApp.setResearchTab('reports')" style="
          background: ${activeTab === 'reports' ? 'var(--cyan-core)' : 'transparent'};
          color: ${activeTab === 'reports' ? 'var(--bg-void)' : 'var(--text-secondary)'};
          border: 1px solid ${activeTab === 'reports' ? 'var(--cyan-core)' : 'rgba(0, 240, 255, 0.2)'};
          font-family: var(--font-telemetry);
          font-size: 10px;
          font-weight: 700;
          padding: 6px 12px;
          cursor: pointer;
          clip-path: var(--chamfer-clip-sm);
        ">
          SAVED REPORTS (${savedReports.length})
        </button>

        <button onclick="window.jarvisApp.setResearchTab('history')" style="
          background: ${activeTab === 'history' ? 'var(--cyan-core)' : 'transparent'};
          color: ${activeTab === 'history' ? 'var(--bg-void)' : 'var(--text-secondary)'};
          border: 1px solid ${activeTab === 'history' ? 'var(--cyan-core)' : 'rgba(0, 240, 255, 0.2)'};
          font-family: var(--font-telemetry);
          font-size: 10px;
          font-weight: 700;
          padding: 6px 12px;
          cursor: pointer;
          clip-path: var(--chamfer-clip-sm);
        ">
          HISTORY
        </button>
      </div>

      ${activeTab === 'search' ? renderSearchTab() : ''}
      ${activeTab === 'reports' ? renderReportsTab() : ''}
      ${activeTab === 'history' ? renderHistoryTab() : ''}

      <!-- Modals -->
      ${activeReport ? renderReportModal(activeReport) : ''}
      ${activeSummary ? renderSummaryModal(activeSummary) : ''}

    </div>
  `;
}

function renderSearchTab() {
  return `
    <!-- Search Input Panel -->
    <div class="hud-panel" style="padding: 12px; display: flex; flex-direction: column; gap: 10px;">
      <div style="display: flex; gap: 8px;">
        <input 
          type="text" 
          id="research-search-input" 
          class="hud-input" 
          placeholder="Enter research topic, query or technology..." 
          value="${searchQuery}"
          onkeydown="if(event.key === 'Enter') window.jarvisApp.handleSearchSubmit()"
        >
        <button onclick="window.jarvisApp.handleSearchSubmit()" class="hud-btn" style="padding: 10px 14px;" ${isSearching ? 'disabled' : ''}>
          <span class="material-symbols-outlined" style="font-size: 18px;">${isSearching ? 'sync' : 'search'}</span>
        </button>
      </div>

      <!-- Quick Topics -->
      <div style="display: flex; align-items: center; gap: 6px; overflow-x: auto; scrollbar-width: none;">
        <span class="label-caps" style="font-size: 8px; white-space: nowrap; color: var(--text-muted);">TOPICS:</span>
        ${['Quantum Computing', 'High-NA EUV Lithography', 'AI Agent Orchestration', 'Photonic Chips', 'Fusion Energy'].map(t => `
          <button onclick="window.jarvisApp.runQuickSearch('${t}')" class="hud-btn-ghost" style="font-size: 9px; padding: 3px 8px; white-space: nowrap;">
            ${t}
          </button>
        `).join('')}
      </div>
    </div>

    <!-- Search Status / Loading Bar -->
    ${isSearching ? `
      <div class="hud-panel" style="padding: 16px; text-align: center; border-color: var(--cyan-core);">
        <div style="font-family: var(--font-telemetry); font-size: 12px; color: var(--cyan-core); margin-bottom: 6px;">
          ORBITAL RADAR QUERYING BACKEND SEARCH PROVIDER...
        </div>
        <div style="height: 3px; width: 100%; background: rgba(0, 240, 255, 0.15); overflow: hidden; position: relative;">
          <div style="height: 100%; width: 40%; background: var(--cyan-core); animation: hud-scan 1.2s infinite ease-in-out;"></div>
        </div>
      </div>
    ` : ''}

    <!-- Search Results Section -->
    ${searchResults.length > 0 ? `
      <div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; padding: 0 2px;">
          <div>
            <span class="label-caps" style="color: var(--cyan-core);">RESULTS (${searchResults.length})</span>
            <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted); margin-left: 6px;">PROVIDER: ${searchMetadata ? searchMetadata.provider : 'DuckDuckGo'}</span>
          </div>
          
          <button onclick="window.jarvisApp.generateCitedReport()" class="hud-btn" style="padding: 5px 10px; font-size: 9px;" ${isGeneratingReport ? 'disabled' : ''}>
            <span class="material-symbols-outlined" style="font-size: 12px;">auto_awesome</span>
            ${isGeneratingReport ? 'Synthesizing...' : `Synthesize Cited Report (${selectedUrlsForReport.size})`}
          </button>
        </div>

        <div style="display: flex; flex-direction: column; gap: 10px;">
          ${searchResults.map((res, idx) => {
            const isSelected = selectedUrlsForReport.has(res.url);
            return `
              <div class="hud-panel" style="padding: 12px; border-left: 3px solid ${isSelected ? 'var(--cyan-core)' : 'rgba(0, 240, 255, 0.15)'};">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4px;">
                  <div style="display: flex; align-items: center; gap: 6px;">
                    <input 
                      type="checkbox" 
                      ${isSelected ? 'checked' : ''} 
                      onchange="window.jarvisApp.toggleSourceSelection('${res.url}')"
                      style="cursor: pointer; accent-color: var(--cyan-core);"
                    >
                    <span class="badge badge-cyan" style="font-size: 8px;">#${res.rank || (idx + 1)}</span>
                    <span class="label-caps" style="font-size: 9px; color: var(--plasma-cobalt); font-weight: 700;">${res.publisher || res.domain}</span>
                  </div>
                  <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted);">${res.published_at || 'Date unavailable'}</span>
                </div>

                <h3 style="font-size: 13px; font-weight: 700; color: var(--text-primary); margin: 6px 0; line-height: 1.35;">
                  ${res.title}
                </h3>

                <p style="font-size: 11px; color: var(--text-secondary); line-height: 1.45; margin-bottom: 10px;">
                  ${res.snippet || 'No snippet preview available.'}
                </p>

                <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(0, 240, 255, 0.08); padding-top: 8px;">
                  <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted); overflow: hidden; text-overflow: ellipsis; max-width: 140px; white-space: nowrap;">
                    ${res.domain}
                  </span>

                  <div style="display: flex; gap: 6px;">
                    <button onclick="window.jarvisApp.summarizeSingleSource('${res.url}', '${encodeURIComponent(res.title)}')" class="hud-btn-ghost" style="font-size: 9px; padding: 4px 8px;">
                      <span class="material-symbols-outlined" style="font-size: 12px;">summarize</span>
                      Summarize
                    </button>

                    <button onclick="window.jarvisApp.openExternalUrl('${res.url}')" class="hud-btn-ghost" style="font-size: 9px; padding: 4px 8px;">
                      <span class="material-symbols-outlined" style="font-size: 12px;">open_in_new</span>
                      Open Source
                    </button>
                  </div>
                </div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    ` : searchMetadata && searchMetadata.error ? `
      <div class="hud-panel" style="padding: 16px; border-color: var(--warning-amber); text-align: center;">
        <span class="material-symbols-outlined" style="color: var(--warning-amber); font-size: 28px;">warning</span>
        <h3 style="font-size: 13px; color: var(--text-primary); margin: 6px 0;">Search Failed</h3>
        <p style="font-size: 11px; color: var(--text-secondary);">${searchMetadata.error}</p>
      </div>
    ` : `
      <div class="hud-panel" style="padding: 24px; text-align: center; border-style: dashed;">
        <span class="material-symbols-outlined" style="color: var(--cyan-core); font-size: 36px; opacity: 0.6;">radar</span>
        <h3 style="font-size: 14px; font-weight: 700; color: var(--text-primary); margin-top: 8px;">Awaiting Research Directive</h3>
        <p style="font-size: 11px; color: var(--text-secondary); max-width: 320px; margin: 4px auto 0 auto; line-height: 1.4;">
          Submit a search query to scan live web sources via backend DuckDuckGo provider with full SSRF isolation and citation verification.
        </p>
      </div>
    `}
  `;
}

function renderReportsTab() {
  return `
    <div>
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; padding: 0 2px;">
        <span class="label-caps" style="color: var(--cyan-core);">PERSISTED RESEARCH REPORTS</span>
        <button onclick="window.jarvisApp.loadSavedReports()" class="hud-btn-ghost" style="font-size: 9px; padding: 3px 8px;">
          <span class="material-symbols-outlined" style="font-size: 12px;">refresh</span>
          Refresh
        </button>
      </div>

      ${savedReports.length === 0 ? `
        <div class="hud-panel" style="padding: 24px; text-align: center;">
          <span class="material-symbols-outlined" style="font-size: 32px; color: var(--text-muted);">description</span>
          <p style="font-size: 12px; color: var(--text-secondary); margin-top: 6px;">No research reports generated yet.</p>
          <button onclick="window.jarvisApp.setResearchTab('search')" class="hud-btn" style="margin-top: 10px; font-size: 10px; padding: 6px 12px;">
            Run a Search
          </button>
        </div>
      ` : `
        <div style="display: flex; flex-direction: column; gap: 10px;">
          ${savedReports.map(rep => `
            <div class="hud-panel" style="padding: 12px;">
              <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4px;">
                <span class="badge badge-cyan" style="font-size: 8px;">VERIFIED REPORT</span>
                <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted);">${rep.created_at ? new Date(rep.created_at).toLocaleDateString() : ''}</span>
              </div>

              <h3 style="font-size: 14px; font-weight: 700; color: var(--text-primary); margin: 4px 0 6px 0;">
                ${rep.title}
              </h3>

              <p style="font-size: 11px; color: var(--text-secondary); line-height: 1.4; margin-bottom: 8px;">
                ${rep.executive_summary ? rep.executive_summary.substring(0, 160) + '...' : 'Structured multi-source intelligence report.'}
              </p>

              <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(0, 240, 255, 0.08); padding-top: 8px;">
                <span class="label-caps" style="font-size: 8px; color: var(--cyan-core);">
                  ${rep.citations ? rep.citations.length : 0} VALIDATED CITATIONS
                </span>

                <div style="display: flex; gap: 6px;">
                  <button onclick="window.jarvisApp.openReportDetail('${rep.id}')" class="hud-btn" style="font-size: 9px; padding: 4px 10px;">
                    Read Report
                  </button>
                  <button onclick="window.jarvisApp.deleteReportAction('${rep.id}')" class="hud-btn-ghost" style="font-size: 9px; padding: 4px 6px; color: var(--warning-amber);">
                    <span class="material-symbols-outlined" style="font-size: 12px;">delete</span>
                  </button>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      `}
    </div>
  `;
}

function renderHistoryTab() {
  return `
    <div>
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; padding: 0 2px;">
        <span class="label-caps" style="color: var(--cyan-core);">RECENT SEARCH QUERIES</span>
        <button onclick="window.jarvisApp.loadSearchHistory()" class="hud-btn-ghost" style="font-size: 9px; padding: 3px 8px;">
          <span class="material-symbols-outlined" style="font-size: 12px;">refresh</span>
          Refresh
        </button>
      </div>

      ${searchHistory.length === 0 ? `
        <div class="hud-panel" style="padding: 24px; text-align: center;">
          <span class="material-symbols-outlined" style="font-size: 32px; color: var(--text-muted);">history</span>
          <p style="font-size: 12px; color: var(--text-secondary); margin-top: 6px;">No search history on record.</p>
        </div>
      ` : `
        <div style="display: flex; flex-direction: column; gap: 8px;">
          ${searchHistory.map(h => `
            <div class="hud-panel" style="padding: 10px 12px; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <div style="font-size: 12px; font-weight: 700; color: var(--text-primary);">${h.query_text}</div>
                <div style="font-size: 9px; color: var(--text-muted); font-family: var(--font-telemetry); margin-top: 2px;">
                  Provider: ${h.provider} | Results: ${h.result_count} | ${new Date(h.created_at).toLocaleTimeString()}
                </div>
              </div>

              <button onclick="window.jarvisApp.runQuickSearch('${h.query_text}')" class="hud-btn" style="font-size: 9px; padding: 4px 10px;">
                Re-Run
              </button>
            </div>
          `).join('')}
        </div>
      `}
    </div>
  `;
}

function renderReportModal(report) {
  return `
    <div style="position: fixed; inset: 0; background: rgba(5, 11, 20, 0.88); backdrop-filter: blur(8px); z-index: 999; display: flex; align-items: center; justify-content: center; padding: 16px;">
      <div class="hud-panel hud-scroll" style="width: 100%; max-width: 680px; max-height: 85vh; overflow-y: auto; padding: 20px; border-color: var(--cyan-core); display: flex; flex-direction: column; gap: 14px; position: relative;">
        
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(0, 240, 255, 0.2); padding-bottom: 10px;">
          <div>
            <div style="display: flex; gap: 6px; align-items: center; margin-bottom: 4px;">
              <span class="badge badge-cyan" style="font-size: 8px;">CITED RESEARCH REPORT</span>
              <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted);">${new Date(report.created_at).toLocaleString()}</span>
            </div>
            <h2 style="font-size: 16px; font-weight: 700; color: var(--text-primary);">${report.title}</h2>
          </div>

          <button onclick="window.jarvisApp.closeReportModal()" class="hud-btn-ghost" style="padding: 4px; border-radius: 50%;">
            <span class="material-symbols-outlined" style="font-size: 20px;">close</span>
          </button>
        </div>

        <!-- Executive Summary -->
        <div class="hud-panel" style="padding: 12px; background: rgba(0, 240, 255, 0.03);">
          <span class="label-caps" style="font-size: 9px; color: var(--cyan-core); display: block; margin-bottom: 4px;">EXECUTIVE SUMMARY</span>
          <p style="font-size: 12px; color: var(--text-primary); line-height: 1.5;">${report.executive_summary}</p>
        </div>

        <!-- Key Facts -->
        ${report.key_facts && report.key_facts.length > 0 ? `
          <div>
            <span class="label-caps" style="font-size: 9px; color: var(--cyan-core); display: block; margin-bottom: 6px;">VALIDATED CLAIMS & KEY FACTS</span>
            <div style="display: flex; flex-direction: column; gap: 6px;">
              ${report.key_facts.map(f => `
                <div style="display: flex; gap: 8px; align-items: flex-start; font-size: 11px; color: var(--text-secondary); line-height: 1.4;">
                  <span class="material-symbols-outlined" style="font-size: 14px; color: var(--cyan-core); margin-top: 1px;">verified</span>
                  <span>${f}</span>
                </div>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <!-- Source Comparison / Agreement & Conflicts -->
        ${report.source_comparison ? `
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
            <div class="hud-panel" style="padding: 10px;">
              <span class="label-caps" style="font-size: 8px; color: #00ff88; display: block; margin-bottom: 4px;">AREAS OF AGREEMENT</span>
              <ul style="margin: 0; padding-left: 14px; font-size: 11px; color: var(--text-secondary);">
                ${(report.source_comparison.areas_of_agreement || ['Multi-source consensus confirmed.']).map(a => `<li>${a}</li>`).join('')}
              </ul>
            </div>

            <div class="hud-panel" style="padding: 10px;">
              <span class="label-caps" style="font-size: 8px; color: var(--warning-amber); display: block; margin-bottom: 4px;">CONFLICTING CLAIMS</span>
              <ul style="margin: 0; padding-left: 14px; font-size: 11px; color: var(--text-secondary);">
                ${(report.source_comparison.conflicting_claims || ['No critical source divergences detected.']).map(c => `<li>${c}</li>`).join('')}
              </ul>
            </div>
          </div>
        ` : ''}

        <!-- Analysis & Implications -->
        ${report.analysis ? `
          <div>
            <span class="label-caps" style="font-size: 9px; color: var(--plasma-cobalt); display: block; margin-bottom: 4px;">JARVIS SYNTHESIS & IMPLICATIONS</span>
            <p style="font-size: 11px; color: var(--text-secondary); line-height: 1.4;">${report.analysis}</p>
          </div>
        ` : ''}

        <!-- Unknowns & Limitations -->
        ${report.unknowns_and_limitations ? `
          <div class="hud-panel" style="padding: 10px; border-color: rgba(255, 170, 0, 0.3);">
            <span class="label-caps" style="font-size: 8px; color: var(--warning-amber); display: block; margin-bottom: 4px;">UNKNOWNS & REASONING BOUNDARIES</span>
            <p style="font-size: 10px; color: var(--text-secondary); line-height: 1.4;">${report.unknowns_and_limitations}</p>
          </div>
        ` : ''}

        <!-- Validated Citations List -->
        <div>
          <span class="label-caps" style="font-size: 9px; color: var(--cyan-core); display: block; margin-bottom: 6px;">STRUCTURED CITATIONS (${report.citations ? report.citations.length : 0})</span>
          <div style="display: flex; flex-direction: column; gap: 6px;">
            ${(report.citations || []).map(cit => `
              <div class="hud-panel" style="padding: 8px 10px; display: flex; justify-content: space-between; align-items: center;">
                <div style="overflow: hidden; max-width: 80%;">
                  <div style="display: flex; gap: 6px; align-items: center; margin-bottom: 2px;">
                    <span class="badge badge-cyan" style="font-size: 8px;">${cit.citation_label}</span>
                    <span style="font-size: 11px; font-weight: 700; color: var(--text-primary); text-overflow: ellipsis; white-space: nowrap; overflow: hidden;">${cit.source_title || 'Web Document'}</span>
                  </div>
                  <div style="font-size: 9px; color: var(--text-muted); font-family: var(--font-telemetry);">
                    ${cit.publisher || cit.domain} • ${cit.source_type} • ${cit.evidence_excerpt ? `"${cit.evidence_excerpt.substring(0, 70)}..."` : 'Verified text span'}
                  </div>
                </div>

                <button onclick="window.jarvisApp.openExternalUrl('${cit.url}')" class="hud-btn-ghost" style="font-size: 9px; padding: 4px 8px;">
                  <span class="material-symbols-outlined" style="font-size: 12px;">link</span>
                  Source
                </button>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Footer Actions -->
        <div style="display: flex; justify-content: flex-end; gap: 8px; border-top: 1px solid rgba(0, 240, 255, 0.15); padding-top: 10px;">
          <button onclick="window.jarvisApp.copyToClipboard('${encodeURIComponent(report.executive_summary)}')" class="hud-btn-ghost" style="font-size: 10px; padding: 6px 12px;">
            <span class="material-symbols-outlined" style="font-size: 14px;">content_copy</span>
            Copy Summary
          </button>
          <button onclick="window.jarvisApp.closeReportModal()" class="hud-btn" style="font-size: 10px; padding: 6px 14px;">
            Close Report
          </button>
        </div>

      </div>
    </div>
  `;
}

function renderSummaryModal(sum) {
  return `
    <div style="position: fixed; inset: 0; background: rgba(5, 11, 20, 0.88); backdrop-filter: blur(8px); z-index: 999; display: flex; align-items: center; justify-content: center; padding: 16px;">
      <div class="hud-panel" style="width: 100%; max-width: 540px; padding: 18px; border-color: var(--cyan-core); display: flex; flex-direction: column; gap: 12px;">
        
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(0, 240, 255, 0.2); padding-bottom: 8px;">
          <div>
            <span class="badge badge-cyan" style="font-size: 8px;">SOURCE INTELLIGENCE</span>
            <h3 style="font-size: 14px; font-weight: 700; color: var(--text-primary); margin-top: 2px;">
              ${sum.title ? decodeURIComponent(sum.title) : 'Web Document'}
            </h3>
          </div>

          <button onclick="window.jarvisApp.closeSummaryModal()" class="hud-btn-ghost" style="padding: 4px;">
            <span class="material-symbols-outlined" style="font-size: 18px;">close</span>
          </button>
        </div>

        ${sum.loading ? `
          <div style="padding: 24px; text-align: center;">
            <div style="font-family: var(--font-telemetry); font-size: 12px; color: var(--cyan-core); margin-bottom: 8px;">
              PARSING HTML & EXTRACTING ARTICLE CONTENT...
            </div>
            <div style="height: 2px; width: 80%; margin: 0 auto; background: var(--cyan-core); animation: hud-scan 1s infinite alternate;"></div>
          </div>
        ` : sum.error ? `
          <div class="hud-panel" style="padding: 12px; border-color: var(--warning-amber);">
            <span class="label-caps" style="color: var(--warning-amber); font-size: 9px;">EXTRACTION ERROR</span>
            <p style="font-size: 11px; color: var(--text-secondary); margin-top: 4px;">${sum.error}</p>
          </div>
        ` : `
          <div style="display: flex; flex-direction: column; gap: 10px;">
            <div style="display: flex; justify-content: space-between; font-size: 9px; color: var(--text-muted); font-family: var(--font-telemetry);">
              <span>PUBLISHER: ${sum.publisher || 'Web Site'}</span>
              <span>DATE: ${sum.published_at}</span>
            </div>

            <div class="hud-panel" style="padding: 10px; background: rgba(0, 240, 255, 0.03);">
              <span class="label-caps" style="font-size: 8px; color: var(--cyan-core); display: block; margin-bottom: 4px;">EXTRACTED SUMMARY</span>
              <p style="font-size: 11px; color: var(--text-primary); line-height: 1.45;">${sum.summary}</p>
            </div>

            ${sum.key_facts && sum.key_facts.length > 0 ? `
              <div>
                <span class="label-caps" style="font-size: 8px; color: var(--cyan-core); display: block; margin-bottom: 4px;">KEY CLAIMS</span>
                <ul style="margin: 0; padding-left: 14px; font-size: 10px; color: var(--text-secondary); line-height: 1.4;">
                  ${sum.key_facts.map(k => `<li>${k}</li>`).join('')}
                </ul>
              </div>
            ` : ''}
          </div>
        `}

        <div style="display: flex; justify-content: flex-end; gap: 8px; border-top: 1px solid rgba(0, 240, 255, 0.1); padding-top: 8px;">
          ${sum.url ? `
            <button onclick="window.jarvisApp.openExternalUrl('${sum.url}')" class="hud-btn-ghost" style="font-size: 9px; padding: 5px 10px;">
              <span class="material-symbols-outlined" style="font-size: 12px;">open_in_new</span>
              Visit Page
            </button>
          ` : ''}
          <button onclick="window.jarvisApp.closeSummaryModal()" class="hud-btn" style="font-size: 9px; padding: 5px 12px;">
            Done
          </button>
        </div>

      </div>
    </div>
  `;
}
