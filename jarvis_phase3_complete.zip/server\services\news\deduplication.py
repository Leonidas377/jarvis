# ==========================================================================
# JARVIS News Deduplication & Event Clustering Engine
# Groups similar breaking headlines across multiple publishers into cohesive event clusters
# ==========================================================================

import re
import uuid
from typing import List, Dict, Any, Tuple
from server.models.schemas import NewsItemOut

STOP_WORDS = {
    "a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "is", "are", "was", "were", "it", "its", "that", "this"
}

def tokenize_headline(text: str) -> set:
    """Extracts significant words from a headline for similarity comparison, normalizing plurals and tech acronyms."""
    words = re.findall(r"\b[a-zA-Z0-9]{2,}\b", text.lower())
    # Light stemming for plurals
    stemmed = [w.rstrip("s") if len(w) > 3 and not w.endswith("ss") else w for w in words]
    return {w for w in stemmed if w not in STOP_WORDS}

def calculate_jaccard_similarity(set_a: set, set_b: set) -> float:
    """Calculates Jaccard overlap between two token sets."""
    if not set_a or not set_b:
        return 0.0
    intersection = len(set_a.intersection(set_b))
    union = len(set_a.union(set_b))
    return intersection / union if union > 0 else 0.0

class NewsClusterer:
    @staticmethod
    def cluster_items(items: List[NewsItemOut], threshold: float = 0.35) -> Tuple[List[Dict[str, Any]], List[NewsItemOut]]:
        """
        Groups duplicate and related news stories into clusters.
        Returns (clusters_list, updated_items_with_cluster_ids).
        """
        clusters: List[Dict[str, Any]] = []
        tokenized_items = [(item, tokenize_headline(item.headline)) for item in items]
        assigned_cluster: Dict[str, str] = {}

        for item, tokens in tokenized_items:
            best_cluster = None
            best_score = 0.0

            # Compare against existing cluster representative headlines
            for cl in clusters:
                score = calculate_jaccard_similarity(tokens, cl["tokens"])
                if score > best_score and score >= threshold:
                    best_score = score
                    best_cluster = cl

            if best_cluster:
                # Add to existing cluster
                best_cluster["item_ids"].append(item.id)
                best_cluster["sources"].append(item.publisher)
                best_cluster["tokens"].update(tokens)
                assigned_cluster[item.id] = best_cluster["id"]
            else:
                # Create a new cluster
                new_cl_id = str(uuid.uuid4())
                new_cluster = {
                    "id": new_cl_id,
                    "representative_headline": item.headline,
                    "summary": item.summary,
                    "tokens": tokens,
                    "item_ids": [item.id],
                    "sources": [item.publisher],
                    "category": item.category,
                    "first_observed_at": item.published_at,
                    "last_observed_at": item.published_at,
                    "importance": "high" if item.is_breaking else "normal"
                }
                clusters.append(new_cluster)
                assigned_cluster[item.id] = new_cl_id

        # Update items with their cluster IDs
        for item in items:
            item.cluster_id = assigned_cluster.get(item.id)

        return clusters, items

clusterer = NewsClusterer()
