# ==========================================================================
# JARVIS Server Configuration
# ==========================================================================

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings:
    PROJECT_NAME: str = "J.A.R.V.I.S. Core Backend"
    VERSION: str = "14.8.0"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    
    # Security
    JWT_SECRET: str = os.getenv("JARVIS_JWT_SECRET", "stark-quantum-neural-secret-key-0499-omega")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 hours
    
    # Database
    DATABASE_FILE: Path = BASE_DIR / "jarvis_vault.db"
    
    # AI Provider
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    DEFAULT_MODEL: str = os.getenv("JARVIS_DEFAULT_MODEL", "gemini-2.5-flash")
    USE_LOCAL_AI_FALLBACK: bool = True

settings = Settings()
