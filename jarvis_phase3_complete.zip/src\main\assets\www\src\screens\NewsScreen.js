// ==========================================================================
// News Screen: World Headline Intelligence
// ==========================================================================

import { store } from '../services/store.js';

let activeCategory = 'all';

export function setNewsCategory(cat) {
  activeCategory = cat;
  window.jarvisApp.render();
}

export function renderNewsScreen() {
  const state = store.state;
  let items = state.newsItems;
  if (activeCategory !== 'all') {
    items = items.filter(n => n.category.toLowerCase() === activeCategory.toLowerCase());
  }

  return `
    <div class="screen-container hud-scroll" style="flex: 1; padding: 14px 14px 84px 14px; display: flex; flex-direction: column; gap: 14px;">
      
      <!-- Top Title Bar with Back Button -->
      <div style="display: flex; align-items: center; justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <button onclick="window.jarvisApp.goBack()" class="hud-btn-ghost" style="width: 32px; height: 32px; padding: 0; display: flex; align-items: center; justify-content: center;">
            <span class="material-symbols-outlined" style="font-size: 18px;">arrow_back</span>
          </button>
          <div>
            <span class="label-caps" style="color: var(--cyan-core);">GLOBAL HEADLINE SCAN</span>
            <h2 class="hud-title" style="font-size: 18px; margin-top: 1px;">News Intelligence</h2>
          </div>
        </div>

        <span class="badge badge-amber" style="font-size: 8px;">DEMO WIRE</span>
      </div>

      <!-- Category Filter Pills -->
      <div style="display: flex; gap: 6px; overflow-x: auto; scrollbar-width: none;">
        ${['all', 'technology', 'economy', 'energy'].map(cat => {
          const isActive = activeCategory === cat;
          return `
            <button onclick="window.jarvisApp.filterNews('${cat}')" style="
              background: ${isActive ? 'var(--cyan-core)' : 'var(--surface-input)'};
              color: ${isActive ? 'var(--bg-void)' : 'var(--text-secondary)'};
              border: 1px solid ${isActive ? 'var(--cyan-core)' : 'rgba(0, 240, 255, 0.2)'};
              font-family: var(--font-telemetry);
              font-size: 10px;
              font-weight: 700;
              text-transform: uppercase;
              padding: 4px 10px;
              cursor: pointer;
              clip-path: var(--chamfer-clip-sm);
            ">
              ${cat}
            </button>
          `;
        }).join('')}
      </div>

      <!-- News Feed Items -->
      <div style="display: flex; flex-direction: column; gap: 10px;">
        ${items.map(news => `
          <div class="hud-panel" style="padding: 12px; border-color: ${news.isBreaking ? 'rgba(255, 42, 85, 0.4)' : 'var(--border-cyan)'};">
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <div style="display: flex; align-items: center; gap: 6px;">
                ${news.isBreaking ? `
                  <span class="badge badge-red" style="font-size: 8px;">
                    <span class="material-symbols-outlined" style="font-size: 10px;">bolt</span>
                    BREAKING
                  </span>
                ` : ''}
                <span class="badge badge-cyan" style="font-size: 8px;">${news.category}</span>
                <span class="label-caps" style="font-size: 8px;">${news.region}</span>
              </div>
              <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted);">${news.timestamp}</span>
            </div>

            <h3 style="font-size: 14px; font-weight: 700; color: ${news.read ? 'var(--text-secondary)' : 'var(--text-primary)'}; margin-bottom: 8px; line-height: 1.35;">
              ${news.headline}
            </h3>

            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(0, 240, 255, 0.08); padding-top: 6px;">
              <span class="label-caps" style="font-size: 8px; color: var(--text-muted);">
                SOURCE: ${news.source}
              </span>

              <div style="display: flex; gap: 6px;">
                <button onclick="window.jarvisApp.markNewsAsRead('${news.id}')" class="hud-btn-ghost" style="font-size: 9px; padding: 2px 6px;">
                  ${news.read ? 'Read' : 'Mark Read'}
                </button>
                <button onclick="window.jarvisApp.toggleSaveNews('${news.id}')" class="hud-btn-ghost" style="font-size: 9px; padding: 2px 6px;">
                  <span class="material-symbols-outlined" style="font-size: 12px;">${news.saved ? 'bookmark' : 'bookmark_border'}</span>
                </button>
              </div>
            </div>

          </div>
        `).join('')}
      </div>

    </div>
  `;
}
