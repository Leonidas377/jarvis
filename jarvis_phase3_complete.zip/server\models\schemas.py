# ==========================================================================
# JARVIS Pydantic Models & Schemas
# ==========================================================================

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, EmailStr, Field
from enum import Enum

class RiskLevel(str, Enum):
    R0_SAFE = "R0_SAFE"
    R1_LOW = "R1_LOW"
    R2_MEDIUM = "R2_MEDIUM"
    R3_HIGH = "R3_HIGH"
    R4_CRITICAL = "R4_CRITICAL"

# ----------------- Auth Schemas -----------------
class UserRegister(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=6)
    display_name: Optional[str] = "Stark Administrator"

class UserLogin(BaseModel):
    username: str
    password: str

class UserOut(BaseModel):
    id: str
    username: str
    email: str
    display_name: str
    created_at: str
    status: str

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut

# ----------------- Conversation Schemas -----------------
class ConversationCreate(BaseModel):
    title: Optional[str] = "General Dialogue"
    mode: Optional[str] = "assistant"

class ConversationOut(BaseModel):
    id: str
    user_id: str
    title: str
    mode: str
    created_at: str
    updated_at: str

class MessageCreate(BaseModel):
    content: str
    conversation_id: Optional[str] = None

class MessageOut(BaseModel):
    id: str
    conversation_id: str
    user_id: str
    role: str
    content: str
    citations: Optional[List[str]] = None
    uncertainty: Optional[str] = None
    created_at: str

# ----------------- Task Schemas -----------------
class TaskCreate(BaseModel):
    title: str = Field(..., min_length=2)
    description: Optional[str] = ""
    priority: Optional[str] = "medium"
    category: Optional[str] = "general"
    due_date: Optional[str] = "Tomorrow"

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    category: Optional[str] = None
    status: Optional[str] = None
    progress: Optional[int] = None
    due_date: Optional[str] = None

class TaskOut(BaseModel):
    id: str
    user_id: str
    title: str
    description: str
    priority: str
    category: str
    status: str
    progress: int
    due_date: Optional[str]
    created_at: str
    updated_at: str

# ----------------- Memory Schemas -----------------
class MemoryCreate(BaseModel):
    category: str = "General"
    key: str
    value: str

class MemoryUpdate(BaseModel):
    category: Optional[str] = None
    key: Optional[str] = None
    value: Optional[str] = None

class MemoryOut(BaseModel):
    id: str
    user_id: str
    category: str
    key: str
    value: str
    user_approved: bool
    created_at: str
    updated_at: str

# ----------------- Approval Schemas -----------------
class ApprovalOut(BaseModel):
    id: str
    user_id: str
    conversation_id: Optional[str]
    tool_name: str
    summary: str
    parameters: Dict[str, Any]
    risk_level: str
    status: str
    created_at: str
    expires_at: str

class ApprovalDecision(BaseModel):
    action: str = Field(..., pattern="^(approve|reject)$")
    reason: Optional[str] = None

# ----------------- Audit Schemas -----------------
class AuditEventOut(BaseModel):
    id: str
    user_id: str
    event_type: str
    actor: str
    resource_type: str
    resource_id: Optional[str]
    summary: str
    status: str
    correlation_id: str
    timestamp: str

# ----------------- Phase 3: Research & Search Schemas -----------------
class SearchRequest(BaseModel):
    query: str = Field(..., min_length=2, max_length=250)
    category: Optional[str] = "all"
    region: Optional[str] = "us-en"
    limit: Optional[int] = Field(default=8, ge=1, le=25)

class SearchResultItem(BaseModel):
    id: str
    title: str
    url: str
    canonical_url: Optional[str] = None
    domain: str
    publisher: Optional[str] = None
    snippet: str
    published_date: Optional[str] = "Date unavailable"
    rank: int = 1
    provider: str
    retrieval_timestamp: str
    saved: bool = False

class SearchResponseOut(BaseModel):
    query_id: str
    query: str
    provider: str
    total_results: int
    results: List[SearchResultItem]
    status: str = "completed"

class SourceFetchRequest(BaseModel):
    url: str

class SourceDocumentOut(BaseModel):
    id: str
    url: str
    canonical_url: Optional[str] = None
    title: Optional[str] = None
    publisher: Optional[str] = None
    author: Optional[str] = None
    published_date: Optional[str] = None
    access_timestamp: str
    extraction_status: str
    extracted_text: Optional[str] = None
    headings: Optional[List[str]] = []
    content_expiry: str

class CitationItem(BaseModel):
    id: str
    source_id: str
    title: str
    publisher: Optional[str] = None
    url: str
    published_date: Optional[str] = None
    excerpt: Optional[str] = None
    source_type: str = "web"

class ResearchReportCreate(BaseModel):
    query: str
    source_urls: Optional[List[str]] = []
    max_sources: Optional[int] = Field(default=3, ge=1, le=5)

class ResearchReportOut(BaseModel):
    id: str
    user_id: str
    title: str
    request_query: str
    executive_summary: str
    key_facts: List[str]
    source_comparison: Optional[List[Dict[str, Any]]] = []
    analysis: Optional[str] = None
    unknowns_and_limitations: Optional[str] = None
    citations: List[CitationItem]
    status: str
    saved: bool = True
    created_at: str
    updated_at: str

# ----------------- Phase 3: News Schemas -----------------
class NewsTopicCreate(BaseModel):
    topic_name: str = Field(..., min_length=2, max_length=100)
    query: str = Field(..., min_length=2, max_length=100)
    category: Optional[str] = "General"
    region: Optional[str] = "Global"
    notifications_enabled: Optional[bool] = False

class NewsTopicOut(BaseModel):
    id: str
    user_id: str
    topic_name: str
    query: str
    category: str
    region: str
    notifications_enabled: bool
    is_active: bool
    created_at: str

class NewsItemOut(BaseModel):
    id: str
    headline: str
    summary: str
    url: str
    canonical_url: Optional[str] = None
    publisher: str
    author: Optional[str] = None
    published_at: str
    retrieval_timestamp: str
    category: str
    region: str
    related_entities: Optional[List[str]] = []
    cluster_id: Optional[str] = None
    is_read: bool = False
    is_saved: bool = False
    is_breaking: bool = False

class NewsBriefingOut(BaseModel):
    briefing_id: str
    title: str
    summary: str
    key_events: List[Dict[str, Any]]
    market_implications: Optional[str] = None
    uncertainty_notes: Optional[str] = None
    timestamp: str
