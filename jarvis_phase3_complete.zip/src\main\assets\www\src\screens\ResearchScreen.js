// ==========================================================================
// Research Screen: Web Intelligence & Citation Notebook
// ==========================================================================

import { store } from '../services/store.js';

let activeCategory = 'all';
let searchQuery = '';
let searchResults = [];

export function setResearchCategory(cat) {
  activeCategory = cat;
  window.jarvisApp.render();
}

export function executeSearch(query) {
  searchQuery = query;
  // Generate simulated verified search results
  searchResults = [
    {
      id: 'sr-1',
      title: `Analysis of ${query || 'Photonic Interconnects'} in High-Density AI Clusters`,
      domain: 'mit.edu/research/computing-2026',
      date: 'Sept 06, 2026',
      snippet: 'Experimental benchmarks indicate an 8.4x throughput leap with 62% reduced thermal dissipation compared to traditional copper traces.',
      citations: ['MIT EECS', 'IEEE SPECTRUM', 'OFFICIAL LAB REPORT']
    },
    {
      id: 'sr-2',
      title: `Global Industrial Roadmap for ${query || 'Semiconductor Supply Chains'}`,
      domain: 'semiconductors.org/insights',
      date: 'Sept 02, 2026',
      snippet: 'Consortium report detailing 2nm production readiness across leading fabrication foundries.',
      citations: ['SIA GLOBAL', 'REUTERS WIRE']
    }
  ];
  window.jarvisApp.render();
}

export function renderResearchScreen() {
  const state = store.state;

  return `
    <div class="screen-container hud-scroll" style="flex: 1; padding: 14px 14px 84px 14px; display: flex; flex-direction: column; gap: 14px;">
      
      <!-- Top Title Bar -->
      <div style="display: flex; align-items: center; justify-content: space-between;">
        <div>
          <span class="label-caps" style="color: var(--cyan-core);">ORBITAL INTELLIGENCE</span>
          <h2 class="hud-title" style="font-size: 18px; margin-top: 2px;">Research Portal</h2>
        </div>

        <button onclick="window.jarvisApp.navigate('news')" class="hud-btn" style="padding: 6px 10px; font-size: 10px;">
          <span class="material-symbols-outlined" style="font-size: 14px;">newspaper</span>
          News Feed
        </button>
      </div>

      <!-- Search Input Panel -->
      <div class="hud-panel" style="padding: 12px; display: flex; flex-direction: column; gap: 10px;">
        <div style="display: flex; gap: 8px;">
          <input 
            type="text" 
            id="research-search-input" 
            class="hud-input" 
            placeholder="Search verified web sources, papers, data..." 
            value="${searchQuery}"
            onkeydown="if(event.key === 'Enter') window.jarvisApp.handleSearchSubmit()"
          >
          <button onclick="window.jarvisApp.handleSearchSubmit()" class="hud-btn" style="padding: 10px 14px;">
            <span class="material-symbols-outlined" style="font-size: 18px;">search</span>
          </button>
        </div>

        <!-- Recent Searches Chips -->
        <div style="display: flex; align-items: center; gap: 6px; overflow-x: auto; scrollbar-width: none;">
          <span class="label-caps" style="font-size: 8px; white-space: nowrap;">RECENT:</span>
          ${state.recentSearches.map(s => `
            <button onclick="window.jarvisApp.runQuickSearch('${s}')" class="hud-btn-ghost" style="font-size: 10px; padding: 3px 8px; white-space: nowrap;">
              ${s}
            </button>
          `).join('')}
        </div>
      </div>

      <!-- Live Search Results Section -->
      ${searchResults.length > 0 ? `
        <div>
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; padding: 0 2px;">
            <span class="label-caps" style="color: var(--cyan-core);">SEARCH RESULTS (${searchResults.length})</span>
            <span class="badge badge-amber" style="font-size: 8px;">DEMO SEARCH ENGINE</span>
          </div>

          <div style="display: flex; flex-direction: column; gap: 10px;">
            ${searchResults.map(res => `
              <div class="hud-panel" style="padding: 12px;">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4px;">
                  <span class="label-caps" style="font-size: 8px; color: var(--plasma-cobalt);">${res.domain}</span>
                  <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted);">${res.date}</span>
                </div>

                <h3 style="font-size: 14px; font-weight: 700; color: var(--text-primary); margin-bottom: 6px;">
                  ${res.title}
                </h3>

                <p style="font-size: 12px; color: var(--text-secondary); line-height: 1.4; margin-bottom: 10px;">
                  ${res.snippet}
                </p>

                <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(0, 240, 255, 0.08); padding-top: 8px;">
                  <div style="display: flex; gap: 4px;">
                    ${res.citations.map(c => `
                      <span class="badge badge-cyan" style="font-size: 7px;">${c}</span>
                    `).join('')}
                  </div>

                  <button onclick="window.jarvisApp.saveSearchResult('${encodeURIComponent(res.title)}', '${res.domain}', '${res.date}', '${encodeURIComponent(res.snippet)}')" class="hud-btn-ghost" style="font-size: 9px; padding: 4px 8px;">
                    <span class="material-symbols-outlined" style="font-size: 12px;">bookmark_add</span>
                    Save Report
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <!-- Saved Research Notebook -->
      <div>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; padding: 0 2px;">
          <span class="label-caps" style="color: var(--text-secondary);">SAVED RESEARCH NOTEBOOK</span>
          <span class="label-caps" style="color: var(--cyan-core);">${state.savedResearch.length} REPORTS</span>
        </div>

        <div style="display: flex; flex-direction: column; gap: 10px;">
          ${state.savedResearch.map(item => `
            <div class="hud-panel" style="padding: 12px;">
              <div style="display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span class="badge badge-cyan" style="font-size: 8px;">${item.category}</span>
                <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted);">${item.date}</span>
              </div>

              <h4 style="font-size: 13px; font-weight: 700; color: var(--text-primary); margin-bottom: 4px;">
                ${item.title}
              </h4>
              <span class="label-caps" style="font-size: 8px; color: var(--text-muted); display: block; margin-bottom: 6px;">
                SOURCE: ${item.domain}
              </span>

              <p style="font-size: 11px; color: var(--text-secondary); line-height: 1.4;">
                ${item.summary}
              </p>
            </div>
          `).join('')}
        </div>
      </div>

    </div>
  `;
}
