# ==========================================================================
# JARVIS Global News Intelligence API Routes
# ==========================================================================

import time
import uuid
import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from server.auth.dependencies import get_optional_user
from server.database import get_db_connection
from server.models.schemas import NewsItemOut, NewsTopicCreate, NewsTopicOut, NewsBriefingOut
from server.services.news import default_news_provider, briefing_generator
from server.services.news.deduplication import clusterer
from server.audit.logger import audit_logger

router = APIRouter(prefix="/api/news", tags=["News & Global Intelligence"])

@router.get("", response_model=List[NewsItemOut])
async def get_news_feed(
    category: Optional[str] = Query("all"),
    limit: int = Query(20, le=50),
    user: dict = Depends(get_optional_user)
):
    items = await default_news_provider.fetch_news(category=category, limit=limit)
    # Apply deduplication and clustering
    _, clustered_items = clusterer.cluster_items(items)
    return clustered_items

@router.post("/{news_id}/read")
async def mark_news_read(news_id: str, user: dict = Depends(get_optional_user)):
    return {"success": True, "news_id": news_id, "is_read": True}

@router.post("/{news_id}/save")
async def save_news_item(news_id: str, user: dict = Depends(get_optional_user)):
    return {"success": True, "news_id": news_id, "is_saved": True}

@router.delete("/{news_id}/save")
async def unsave_news_item(news_id: str, user: dict = Depends(get_optional_user)):
    return {"success": True, "news_id": news_id, "is_saved": False}

# --- Topic Subscriptions ---
@router.get("/topics", response_model=List[NewsTopicOut])
async def list_topics(user: dict = Depends(get_optional_user)):
    async with get_db_connection() as db:
        cur = await db.execute("""
            SELECT id, user_id, topic_name, query, category, region, notifications_enabled, is_active, created_at
            FROM news_topics
            WHERE user_id = ?
            ORDER BY created_at DESC
        """, (user["id"],))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

@router.post("/topics", response_model=NewsTopicOut, status_code=status.HTTP_201_CREATED)
async def subscribe_topic(topic_in: NewsTopicCreate, user: dict = Depends(get_optional_user)):
    user_id = user["id"]
    topic_id = str(uuid.uuid4())
    now_str = time.strftime("%Y-%m-%d %H:%M:%S")

    async with get_db_connection() as db:
        await db.execute("""
            INSERT INTO news_topics (
                id, user_id, topic_name, query, category, region, notifications_enabled, is_active, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)
        """, (
            topic_id, user_id, topic_in.topic_name, topic_in.query,
            topic_in.category or "General", topic_in.region or "Global",
            1 if topic_in.notifications_enabled else 0, now_str
        ))
        await db.commit()

    await audit_logger.log_event(
        event_type="NEWS_TOPIC_SUBSCRIBED",
        action="news.topic_create",
        user_id=user_id,
        resource_id=topic_id,
        details={"topic_name": topic_in.topic_name, "query": topic_in.query}
    )

    return NewsTopicOut(
        id=topic_id,
        user_id=user_id,
        topic_name=topic_in.topic_name,
        query=topic_in.query,
        category=topic_in.category or "General",
        region=topic_in.region or "Global",
        notifications_enabled=bool(topic_in.notifications_enabled),
        is_active=True,
        created_at=now_str
    )

@router.delete("/topics/{topic_id}")
async def delete_topic(topic_id: str, user: dict = Depends(get_optional_user)):
    async with get_db_connection() as db:
        cur = await db.execute("DELETE FROM news_topics WHERE id = ? AND user_id = ?", (topic_id, user["id"]))
        await db.commit()
        if cur.rowcount == 0:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="News topic subscription not found.")

    await audit_logger.log_event(
        event_type="NEWS_TOPIC_REMOVED",
        action="news.topic_delete",
        user_id=user["id"],
        resource_id=topic_id
    )
    return {"success": True, "topic_id": topic_id, "message": "Unfollowed topic subscription."}

# --- On-Demand Executive News Briefing ---
@router.post("/briefings", response_model=NewsBriefingOut)
async def generate_briefing(category: Optional[str] = Query("all"), user: dict = Depends(get_optional_user)):
    user_id = user["id"]
    items = await default_news_provider.fetch_news(category=category or "all", limit=20)
    briefing = briefing_generator.generate_briefing(items, topic=f"{category.title()} Intelligence Summary")

    await audit_logger.log_event(
        event_type="NEWS_BRIEFING_GENERATED",
        action="news.briefing_generate",
        user_id=user_id,
        correlation_id=briefing.briefing_id,
        details={"category": category, "events_count": len(briefing.key_events)}
    )

    return briefing
