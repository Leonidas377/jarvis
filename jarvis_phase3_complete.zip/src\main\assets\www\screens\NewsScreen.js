// ==========================================================================
// News Screen: Real-Time World Headline Intelligence, Clustering & Briefings
// ==========================================================================

import { store } from '../services/store.js';
import { jarvisApi } from '../services/api.js';

let activeCategory = 'all';
let newsItems = [];
let eventClusters = [];
let subscribedTopics = [];
let activeBriefing = null; // On-demand briefing modal data
let isFetchingNews = false;
let isGeneratingBriefing = false;
let showTopicsModal = false;
let providerStatus = 'LIVE RSS WIRE';

export function setNewsCategory(cat) {
  activeCategory = cat;
  loadNewsData();
}

export async function loadNewsData() {
  isFetchingNews = true;
  window.jarvisApp.render();

  try {
    const data = await jarvisApi.getNews(activeCategory === 'all' ? null : activeCategory, null, 25);
    newsItems = data.items || [];
    eventClusters = data.clusters || [];
    providerStatus = data.provider === 'Aggregated RSS Feeds' ? 'LIVE WIRE' : 'DEMO MODE';
  } catch (err) {
    console.warn('Failed to fetch real news:', err);
    providerStatus = err.message.includes('PROVIDER_NOT_CONFIGURED') ? 'PROVIDER NOT CONFIGURED' : 'OFFLINE';
  } finally {
    isFetchingNews = false;
    window.jarvisApp.render();
  }
}

export async function loadTopics() {
  try {
    const data = await jarvisApi.getNewsTopics();
    subscribedTopics = data.topics || [];
  } catch (err) {
    console.warn('Failed to load news topics:', err);
  }
  window.jarvisApp.render();
}

export async function subscribeTopicAction(topicName) {
  if (!topicName || !topicName.trim()) return;
  try {
    await jarvisApi.createNewsTopic(topicName.trim(), topicName.trim(), { category: activeCategory });
    await loadTopics();
    alert(`Subscribed to topic "${topicName}". Intelligence radar active.`);
  } catch (err) {
    alert(`Failed to follow topic: ${err.message}`);
  }
}

export async function unsubscribeTopicAction(topicId) {
  try {
    await jarvisApi.deleteNewsTopic(topicId);
    await loadTopics();
  } catch (err) {
    alert(`Failed to unfollow topic: ${err.message}`);
  }
}

export async function toggleArticleRead(newsId, currentRead) {
  try {
    await jarvisApi.markNewsRead(newsId);
    const item = newsItems.find(n => n.id === newsId);
    if (item) item.read = !currentRead;
    window.jarvisApp.render();
  } catch (err) {
    console.warn('Failed to toggle read state:', err);
  }
}

export async function toggleArticleSaved(newsId, currentSaved) {
  try {
    await jarvisApi.toggleNewsSaved(newsId, !currentSaved);
    const item = newsItems.find(n => n.id === newsId);
    if (item) item.saved = !currentSaved;
    window.jarvisApp.render();
  } catch (err) {
    console.warn('Failed to toggle saved state:', err);
  }
}

export async function generateNewsBriefing() {
  isGeneratingBriefing = true;
  window.jarvisApp.render();

  try {
    const briefing = await jarvisApi.createNewsBriefing(activeCategory === 'all' ? null : activeCategory, '24h');
    activeBriefing = briefing;
  } catch (err) {
    alert(`Failed to synthesize intelligence briefing: ${err.message}`);
  } finally {
    isGeneratingBriefing = false;
    window.jarvisApp.render();
  }
}

export function closeBriefingModal() {
  activeBriefing = null;
  window.jarvisApp.render();
}

export function toggleTopicsModal(show) {
  showTopicsModal = show;
  if (show) loadTopics();
  window.jarvisApp.render();
}

export function openArticleLink(url) {
  if (!url) return;
  window.open(url, '_blank', 'noopener,noreferrer');
}

export function renderNewsScreen() {
  return `
    <div class="screen-container hud-scroll" style="flex: 1; padding: 14px 14px 84px 14px; display: flex; flex-direction: column; gap: 14px;">
      
      <!-- Top Title Bar -->
      <div style="display: flex; align-items: center; justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <button onclick="window.jarvisApp.goBack()" class="hud-btn-ghost" style="width: 32px; height: 32px; padding: 0; display: flex; align-items: center; justify-content: center;">
            <span class="material-symbols-outlined" style="font-size: 18px;">arrow_back</span>
          </button>
          <div>
            <span class="label-caps" style="color: var(--cyan-core); letter-spacing: 0.15em;">GLOBAL TELEMETRY STREAM</span>
            <h2 class="hud-title" style="font-size: 18px; margin-top: 1px;">News Intelligence</h2>
          </div>
        </div>

        <div style="display: flex; gap: 6px; align-items: center;">
          <span class="badge badge-cyan" style="font-size: 8px;">${providerStatus}</span>
          <button onclick="window.jarvisApp.toggleTopicsModal(true)" class="hud-btn-ghost" style="padding: 6px 8px; font-size: 10px;" title="Follow Topics">
            <span class="material-symbols-outlined" style="font-size: 14px;">subscriptions</span>
          </button>
        </div>
      </div>

      <!-- Control Strip: Category Filter Pills & On-Demand Briefing -->
      <div style="display: flex; justify-content: space-between; align-items: center; gap: 8px;">
        <div style="display: flex; gap: 6px; overflow-x: auto; scrollbar-width: none; flex: 1;">
          ${['all', 'technology', 'business', 'science', 'world', 'energy'].map(cat => {
            const isActive = activeCategory === cat;
            return `
              <button onclick="window.jarvisApp.filterNews('${cat}')" style="
                background: ${isActive ? 'var(--cyan-core)' : 'var(--surface-input)'};
                color: ${isActive ? 'var(--bg-void)' : 'var(--text-secondary)'};
                border: 1px solid ${isActive ? 'var(--cyan-core)' : 'rgba(0, 240, 255, 0.2)'};
                font-family: var(--font-telemetry);
                font-size: 10px;
                font-weight: 700;
                text-transform: uppercase;
                padding: 4px 10px;
                cursor: pointer;
                clip-path: var(--chamfer-clip-sm);
                white-space: nowrap;
              ">
                ${cat}
              </button>
            `;
          }).join('')}
        </div>

        <button onclick="window.jarvisApp.generateNewsBriefing()" class="hud-btn" style="padding: 6px 10px; font-size: 9px; white-space: nowrap;" ${isGeneratingBriefing ? 'disabled' : ''}>
          <span class="material-symbols-outlined" style="font-size: 12px;">summarize</span>
          ${isGeneratingBriefing ? 'Synthesizing...' : 'Generate Briefing'}
        </button>
      </div>

      <!-- Refresh Status / Telemetry bar -->
      ${isFetchingNews ? `
        <div class="hud-panel" style="padding: 12px; text-align: center; border-color: var(--cyan-core);">
          <div style="font-family: var(--font-telemetry); font-size: 11px; color: var(--cyan-core); margin-bottom: 4px;">
            RECEIVING MULTI-SOURCE WIRE TELEMETRY...
          </div>
          <div style="height: 2px; width: 100%; background: rgba(0, 240, 255, 0.15); overflow: hidden;">
            <div style="height: 100%; width: 50%; background: var(--cyan-core); animation: hud-scan 1s infinite alternate;"></div>
          </div>
        </div>
      ` : ''}

      <!-- Clustered Events Section -->
      ${eventClusters.length > 0 ? `
        <div style="display: flex; flex-direction: column; gap: 8px;">
          <span class="label-caps" style="color: var(--cyan-core); font-size: 9px;">IDENTIFIED EVENT CLUSTERS (${eventClusters.length})</span>
          <div style="display: flex; gap: 8px; overflow-x: auto; scrollbar-width: none; padding-bottom: 4px;">
            ${eventClusters.map(c => `
              <div class="hud-panel" style="min-width: 220px; max-width: 260px; padding: 10px; flex-shrink: 0; border-left: 2px solid var(--plasma-cobalt);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                  <span class="badge badge-cyan" style="font-size: 7px;">${c.related_item_ids.length} OUTLETS</span>
                  <span class="font-telemetry" style="font-size: 7px; color: var(--text-muted);">${c.importance || 'NORMAL'}</span>
                </div>
                <div style="font-size: 11px; font-weight: 700; color: var(--text-primary); line-height: 1.3; margin-bottom: 4px;">
                  ${c.representative_headline}
                </div>
                <p style="font-size: 9px; color: var(--text-secondary); margin: 0; line-height: 1.35;">
                  ${c.summary ? c.summary.substring(0, 90) + '...' : ''}
                </p>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <!-- News Feed Items -->
      <div style="display: flex; flex-direction: column; gap: 10px;">
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 0 2px;">
          <span class="label-caps" style="color: var(--text-secondary);">ARTICLES & DISPATCHES (${newsItems.length})</span>
          <button onclick="window.jarvisApp.loadNewsData()" class="hud-btn-ghost" style="font-size: 9px; padding: 2px 6px;">
            <span class="material-symbols-outlined" style="font-size: 12px;">refresh</span>
            Refresh
          </button>
        </div>

        ${newsItems.length === 0 && !isFetchingNews ? `
          <div class="hud-panel" style="padding: 24px; text-align: center;">
            <span class="material-symbols-outlined" style="font-size: 32px; color: var(--text-muted);">newspaper</span>
            <p style="font-size: 12px; color: var(--text-secondary); margin-top: 6px;">No articles found for category "${activeCategory}".</p>
            <button onclick="window.jarvisApp.loadNewsData()" class="hud-btn" style="margin-top: 8px; font-size: 10px; padding: 4px 10px;">
              Re-Scan Feeds
            </button>
          </div>
        ` : ''}

        ${newsItems.map(news => `
          <div class="hud-panel" style="padding: 12px; border-color: ${news.is_breaking ? 'rgba(255, 42, 85, 0.5)' : 'var(--border-cyan)'}; opacity: ${news.read ? '0.7' : '1.0'};">
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <div style="display: flex; align-items: center; gap: 6px;">
                ${news.is_breaking ? `
                  <span class="badge badge-red" style="font-size: 8px;">
                    <span class="material-symbols-outlined" style="font-size: 10px;">bolt</span>
                    BREAKING
                  </span>
                ` : ''}
                <span class="badge badge-cyan" style="font-size: 8px;">${(news.categories && news.categories[0]) || 'GENERAL'}</span>
                <span class="label-caps" style="font-size: 8px; color: var(--plasma-cobalt);">${news.publisher}</span>
              </div>
              <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted);">${news.published_at ? new Date(news.published_at).toLocaleTimeString() : 'Recent'}</span>
            </div>

            <h3 style="font-size: 13px; font-weight: 700; color: ${news.read ? 'var(--text-secondary)' : 'var(--text-primary)'}; margin-bottom: 6px; line-height: 1.35;">
              ${news.headline}
            </h3>

            <p style="font-size: 11px; color: var(--text-secondary); line-height: 1.4; margin-bottom: 8px;">
              ${news.summary || 'Click source for full coverage.'}
            </p>

            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(0, 240, 255, 0.08); padding-top: 6px;">
              <span class="label-caps" style="font-size: 8px; color: var(--text-muted);">
                ${news.author ? `BY ${news.author.toUpperCase()}` : `WIRE: ${news.publisher.toUpperCase()}`}
              </span>

              <div style="display: flex; gap: 6px; align-items: center;">
                <button onclick="window.jarvisApp.toggleArticleRead('${news.id}', ${news.read || false})" class="hud-btn-ghost" style="font-size: 9px; padding: 2px 6px;">
                  ${news.read ? 'Mark Unread' : 'Mark Read'}
                </button>
                <button onclick="window.jarvisApp.toggleArticleSaved('${news.id}', ${news.saved || false})" class="hud-btn-ghost" style="font-size: 9px; padding: 2px 6px;">
                  <span class="material-symbols-outlined" style="font-size: 12px;">${news.saved ? 'bookmark' : 'bookmark_border'}</span>
                </button>
                <button onclick="window.jarvisApp.openArticleLink('${news.url}')" class="hud-btn-ghost" style="font-size: 9px; padding: 2px 6px;">
                  <span class="material-symbols-outlined" style="font-size: 12px;">open_in_new</span>
                </button>
              </div>
            </div>

          </div>
        `).join('')}
      </div>

      <!-- Modals -->
      ${activeBriefing ? renderBriefingModal(activeBriefing) : ''}
      ${showTopicsModal ? renderTopicsModal(subscribedTopics) : ''}

    </div>
  `;
}

function renderBriefingModal(briefing) {
  return `
    <div style="position: fixed; inset: 0; background: rgba(5, 11, 20, 0.88); backdrop-filter: blur(8px); z-index: 999; display: flex; align-items: center; justify-content: center; padding: 16px;">
      <div class="hud-panel hud-scroll" style="width: 100%; max-width: 650px; max-height: 85vh; overflow-y: auto; padding: 20px; border-color: var(--cyan-core); display: flex; flex-direction: column; gap: 14px;">
        
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(0, 240, 255, 0.2); padding-bottom: 10px;">
          <div>
            <span class="badge badge-cyan" style="font-size: 8px;">INTELLIGENCE BRIEFING</span>
            <h2 style="font-size: 16px; font-weight: 700; color: var(--text-primary); margin-top: 2px;">
              ${briefing.title}
            </h2>
            <div style="font-size: 9px; color: var(--text-muted); font-family: var(--font-telemetry);">
              SYNTHESIZED: ${new Date(briefing.created_at).toLocaleString()} | WINDOW: 24 HOURS
            </div>
          </div>

          <button onclick="window.jarvisApp.closeBriefingModal()" class="hud-btn-ghost" style="padding: 4px;">
            <span class="material-symbols-outlined" style="font-size: 20px;">close</span>
          </button>
        </div>

        <!-- Key Events -->
        <div>
          <span class="label-caps" style="font-size: 9px; color: var(--cyan-core); display: block; margin-bottom: 8px;">TOP DEVELOPMENTS & STRATEGIC IMPACT</span>
          <div style="display: flex; flex-direction: column; gap: 10px;">
            ${(briefing.key_events || []).map(ev => `
              <div class="hud-panel" style="padding: 10px 12px; background: rgba(0, 240, 255, 0.02);">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 4px;">
                  <span style="font-size: 12px; font-weight: 700; color: var(--text-primary);">${ev.headline}</span>
                  ${ev.source_link ? `
                    <button onclick="window.jarvisApp.openArticleLink('${ev.source_link}')" class="hud-btn-ghost" style="font-size: 8px; padding: 2px 6px;">
                      <span class="material-symbols-outlined" style="font-size: 10px;">link</span>
                      Source
                    </button>
                  ` : ''}
                </div>

                <div style="font-size: 11px; color: var(--plasma-cobalt); margin-bottom: 4px;">
                  <strong>Why it matters:</strong> ${ev.why_it_matters}
                </div>

                ${ev.uncertainty ? `
                  <div style="font-size: 9px; color: var(--warning-amber); font-style: italic;">
                    Boundary Note: ${ev.uncertainty}
                  </div>
                ` : ''}
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Market Observations (Strictly Read-Only Analysis) -->
        ${briefing.market_observations ? `
          <div class="hud-panel" style="padding: 12px; border-color: rgba(255, 170, 0, 0.3);">
            <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
              <span class="badge badge-amber" style="font-size: 8px;">READ-ONLY ANALYSIS</span>
              <span class="label-caps" style="font-size: 8px; color: var(--warning-amber);">MARKET OBSERVATIONS & IMPLICATIONS</span>
            </div>
            <p style="font-size: 11px; color: var(--text-secondary); line-height: 1.45;">
              ${briefing.market_observations}
            </p>
            <div style="font-size: 8px; color: var(--text-muted); margin-top: 4px;">
              Notice: Information is observational only. No financial trading or investment advice.
            </div>
          </div>
        ` : ''}

        <!-- Citations / References count -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid rgba(0, 240, 255, 0.1); padding-top: 10px;">
          <span class="font-telemetry" style="font-size: 9px; color: var(--cyan-core);">
            CONFIDENCE: 98.6% • SOURCES: ${(briefing.citations && briefing.citations.length) || 4} CITATIONS
          </span>

          <div style="display: flex; gap: 8px;">
            <button onclick="window.jarvisApp.copyToClipboard('${encodeURIComponent(briefing.title)}') " class="hud-btn-ghost" style="font-size: 10px; padding: 6px 12px;">
              Copy Briefing
            </button>
            <button onclick="window.jarvisApp.closeBriefingModal()" class="hud-btn" style="font-size: 10px; padding: 6px 14px;">
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  `;
}

function renderTopicsModal(topics) {
  return `
    <div style="position: fixed; inset: 0; background: rgba(5, 11, 20, 0.88); backdrop-filter: blur(8px); z-index: 999; display: flex; align-items: center; justify-content: center; padding: 16px;">
      <div class="hud-panel" style="width: 100%; max-width: 480px; padding: 18px; border-color: var(--cyan-core); display: flex; flex-direction: column; gap: 12px;">
        
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(0, 240, 255, 0.2); padding-bottom: 8px;">
          <div>
            <span class="badge badge-cyan" style="font-size: 8px;">TOPIC RADAR</span>
            <h3 style="font-size: 14px; font-weight: 700; color: var(--text-primary); margin-top: 2px;">
              Subscribed Intelligence Topics
            </h3>
          </div>

          <button onclick="window.jarvisApp.toggleTopicsModal(false)" class="hud-btn-ghost" style="padding: 4px;">
            <span class="material-symbols-outlined" style="font-size: 18px;">close</span>
          </button>
        </div>

        <!-- Add Topic Form -->
        <div style="display: flex; gap: 6px;">
          <input 
            type="text" 
            id="new-topic-input" 
            class="hud-input" 
            placeholder="Follow company or topic (e.g. ASML, Fusion)..."
            onkeydown="if(event.key === 'Enter') { const v = this.value; this.value=''; window.jarvisApp.subscribeTopicAction(v); }"
          >
          <button onclick="const v = document.getElementById('new-topic-input').value; document.getElementById('new-topic-input').value=''; window.jarvisApp.subscribeTopicAction(v);" class="hud-btn" style="padding: 6px 12px; font-size: 10px;">
            Follow
          </button>
        </div>

        <!-- Current Subscriptions -->
        <div style="display: flex; flex-direction: column; gap: 6px; max-height: 240px; overflow-y: auto;">
          ${topics.length === 0 ? `
            <div style="padding: 16px; text-align: center; color: var(--text-muted); font-size: 11px;">
              No custom topic subscriptions active.
            </div>
          ` : topics.map(t => `
            <div class="hud-panel" style="padding: 8px 10px; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <span style="font-size: 12px; font-weight: 700; color: var(--text-primary);">${t.topic_name}</span>
                <span class="font-telemetry" style="font-size: 8px; color: var(--text-muted); margin-left: 6px;">${new Date(t.created_at).toLocaleDateString()}</span>
              </div>

              <button onclick="window.jarvisApp.unsubscribeTopicAction('${t.id}')" class="hud-btn-ghost" style="font-size: 8px; padding: 2px 6px; color: var(--warning-amber);">
                Unfollow
              </button>
            </div>
          `).join('')}
        </div>

        <div style="display: flex; justify-content: flex-end; border-top: 1px solid rgba(0, 240, 255, 0.1); padding-top: 8px;">
          <button onclick="window.jarvisApp.toggleTopicsModal(false)" class="hud-btn" style="font-size: 9px; padding: 5px 12px;">
            Done
          </button>
        </div>

      </div>
    </div>
  `;
}
